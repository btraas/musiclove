CREATE TRIGGER on_insert_item_setInMyLibraryColumn AFTER INSERT ON item_store BEGIN UPDATE item SET in_my_library = ( CASE WHEN new.home_sharing_id OR (new.store_saga_id AND new.cloud_in_my_library) OR new.purchase_history_id OR (new.sync_id AND new.sync_in_my_library) OR new.is_ota_purchased THEN 1 ELSE 0 END) WHERE item_pid = new.item_pid; END;

